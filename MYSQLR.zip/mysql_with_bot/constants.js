module.exports = {
    redisDataKeys: {
        LAB_LIST: "lablist"
    },
    productStatus: {
        INACTIVE: 1,
        ACTIVE: 2,
        
    }
};
